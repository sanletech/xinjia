$('.db_top').click(function(){
    $(this).next('.dingdan').toggle();
});