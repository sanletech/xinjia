<?php
/*
 *  航线运价批量导入导出
 */
namespace app\admin\controller;
use app\admin\common\Base;
use think\Request;
use think\Loader;
use think\Db;
use app\admin\model\ExportExcelDroplist;

class BulkData extends Base{
 
    //港到港批量导入页面
    public function price_route_excel(){
        return $this->view->fetch('excel/price_route_excel');
    }
    
    //港到港数据导入
    public function insert_excel()
    {
    	Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        Loader::import('PHPExcel.Classes.PHPExcel.Reader.Excel5');
        $PHPExcel = new \PHPExcel();
        //获取表单上传文件
        $file = request()->file('excel');
 
        // echo function_exists($connect->validate);die;
        $info = $file->validate(['size'=>15678,'ext'=>'xlsx,xls,csv'])->move(ROOT_PATH . 'public' . DS . 'excel');
        if ($info) {
            $exclePath = $info->getSaveName();
              //获取文件名
            $file_name = ROOT_PATH . 'public' . DS . 'excel' . DS . $exclePath;
               //上传文件的地址
            $objReader =\PHPExcel_IOFactory::createReader('Excel2007');
            $obj_PHPExcel =$objReader->load($file_name, $encode = 'utf-8');
              //加载文件内容,编码utf-8
            $excel_array=$obj_PHPExcel->getsheet(0)->toArray();
             print_r($excel_array);die;
               //转换为数组格式
            array_shift($excel_array);
              //删除第一个数组(标题);
            $city = [];
            $error_infos = [];
            $login_info = [];
            $i=0;
            // $j=2;
            foreach($excel_array as $k=>$v) {
				
                $sn = Db::name('agent')->where('agent_sn',$v[0])->find();
                if ($sn) {
                	$j = $k+2;
                	$error_infos[$k] = "第{$j}条代理商编号已存在";
                	$i++;
                	continue;
                }
				$city[$k]['agent_sn'] 		= $v[0];
                $city[$k]['agent_name'] 	= $v[1];
                $city[$k]['agent_phone'] 	= $v[2];
                $city[$k]['agent_fuzearea'] = $v[3];                
                $city[$k]['root_id'] 		= $v[4];
                $city[$k]['agent_member'] 	= $v[5];
                $city[$k]['agent_event'] 	= $v[6];
                $city[$k]['agent_areainfo'] = $v[7];
                               
                $i++;
            }
            // print_r($city);die;
            $success = Db::name('agent')->insertAll($city);		
            $error=$i-$success;  
            $error_infos['msg'] = "总{$i}条，成功{$success}条，失败{$error}条。";
 
            if ($i>0 && $res2>0) {
            	return $this->ok(205,"xc",$error_infos);
            }else{
            	return $this->no(300,'导入失败');
            }
             //批量插入数据
        } else {
            echo $file->getError();
        }
    }
    
    
    //所有路线的到处
    public function out_excel()
    {
        //导出
	//##########################################################################
        $lists =Db::name('seaprice')->alias('SP')
            ->join('hl_ship_route SR','SR.id=SP.route_id','left')
            ->join('hl_sea_bothend SB','SB.sealine_id =SR.bothend_id','left')
            ->join('hl_sea_middle SM','SR.middle_id=SM.sealine_id','left')
            ->join('hl_port P1','P1.port_code= SB.sl_start','left')
            ->join('hl_port P2','P2.port_code= SB.sl_end','left')
            ->join('hl_port P3','P3.port_code= SM.sl_middle','left')
            ->join('hl_shipcompany SC',"SC.id=SP.ship_id and SC.status='1'",'left')
            ->join('hl_boat B','B.id=SP.boat_id','left')
            ->field("SP.id,SP.ship_id,SC.ship_short_name,SP.route_id,P1.port_name s_port,P2.port_name e_port,"
            . " group_concat(distinct P3.port_name order by SM.sequence separator '-') m_port,"
          . " SP.price_20GP,SP.price_40HQ,SP.shipping_date,SP.cutoff_date,SP.sea_limitation,SP.ETA,SP.EDD,SP.mtime,"
            . " SP.boat_id,B.boat_name,B.boat_code,SP.generalize,price_description")
             ->order('SP.ship_id,SP.mtime DESC')->group('SP.route_id,SP.ship_id')->select();
   
        foreach ($lists as $key => $list) {
            $lists[$key]['ship_short_name'] =rtrim($list['ship_id'].'_'.$list['ship_short_name'],'_');
            $lists[$key]['boat_name'] =rtrim(implode('_', array($list['ship_id'],$list['boat_id'],$list['boat_code'])),'_');
        }    
//        $this->_p($lists);exit;
       
	$file_name = date('Y-m-d_His').'.xlsx';  
        $path = dirname( ROOT_PATH . 'public' . DS . 'uploads/excel');       
        Loader::import('PHPExcel.Classes.PHPExcel'); //手动引入PHPExcel.php
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
      
        $PHPExcel = new \PHPExcel(); //实例化
//         print_r($PHPExcel);die;
        $PHPSheet = $PHPExcel->getActiveSheet();
        $PHPSheet->setTitle("航线运价");  //给当前活动sheet设置名称
        $PHPSheet->setCellValue("A1","ID");//表格数据
        $PHPSheet->setCellValue("B1","船公司ID");
        $PHPSheet->setCellValue("C1","船名");
        $PHPSheet->setCellValue("D1","路线id");
        $PHPSheet->setCellValue("E1","起运港口");
        $PHPSheet->setCellValue("F1","目的港口");
        $PHPSheet->setCellValue("G1","中间港口");
        $PHPSheet->setCellValue("H1","船舶ID");
        $PHPSheet->setCellValue("I1","船舶名字");
        $PHPSheet->setCellValue("J1","船舶航次");
        $PHPSheet->setCellValue("K1","是否推荐");
        $PHPSheet->setCellValue("L1","价格说明");
        $i = 2;
		foreach($lists as $key => $value){
        	$PHPSheet->setCellValue('A'.$i,''.$value['id']);
        	$PHPSheet->setCellValue('B'.$i,''.$value['ship_id']);
        	$PHPSheet->setCellValue('C'.$i,''.$value['ship_short_name']);
        	$PHPSheet->setCellValue('D'.$i,''.$value['route_id']);
        	$PHPSheet->setCellValue('E'.$i,''.$value['s_port']);
        	$PHPSheet->setCellValue('F'.$i,''.$value['e_port']);
        	$PHPSheet->setCellValue('G'.$i,''.$value['m_port']);
        	$PHPSheet->setCellValue('H'.$i,''.$value['boat_id']);
        	$PHPSheet->setCellValue('I'.$i,''.$value['boat_name']);
        	$PHPSheet->setCellValue('J'.$i,''.$value['boat_code']);
                $PHPSheet->setCellValue('K'.$i,''.$value['generalize']);
                $PHPSheet->setCellValue('L'.$i,''.$value['price_description']);
        	$i++;
    	}
   
//        $PHPWriter = PHPExcel_IOFactory::createWriter($PHPExcel, 'Excel5');
//        header('Content-Disposition: attachment;filename='.$file_name);
//        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
//        header('Cache-Control: max-age=0');
//        $PHPWriter->save('php://output');
        
        $PHPWriter = \PHPExcel_IOFactory::createWriter($PHPExcel,"Excel2007"); //创建生成的格式
        ob_end_clean();//清除缓冲区,避免乱码
        header('Content-Disposition: attachment;filename='.$file_name); //下载下来的表格名
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); //表示在$path路径下面生成demo.xlsx文件
        
        header('Cache-Control: max-age=0');
        $PHPWriter->save("php://output");exit;
     }
     
    public function actionTest()
    {
        $subject = 'demo';
        $tile = ['部门','职位'];
        $data = [
               [   'name' => '设计部',
                   'children' => ['设计师', '设计主管']
               ],
               [   'name' => '业务部',
                   'children' => ['业务员', '业务主管']
               ]
          ];

        $excel = new ExportExcelDroplist();
        $excel->export($subject, $tile, $data);
    }
     
    public function aa() {
         $lists =Db::name('seaprice')->alias('SP')
            ->join('hl_ship_route SR','SR.id=SP.route_id','left')
            ->join('hl_sea_bothend SB','SB.sealine_id =SR.bothend_id','left')
            ->join('hl_sea_middle SM','SR.middle_id=SM.sealine_id','left')
            ->join('hl_port P1','P1.port_code= SB.sl_start','left')
            ->join('hl_port P2','P2.port_code= SB.sl_end','left')
            ->join('hl_port P3','P3.port_code= SM.sl_middle','left')
            ->join('hl_shipcompany SC',"SC.id=SP.ship_id and SC.status='1'",'left')
            ->join('hl_boat B','B.id=SP.boat_id','left')
            ->field("SP.id,SP.ship_id,SC.ship_short_name,SP.route_id,P1.port_name s_port,P2.port_name e_port,"
            . " group_concat(distinct P3.port_name order by SM.sequence separator '-') m_port,"
         // . " SP.price_20GP,SP.price_40HQ,SP.shipping_date,SP.cutoff_date,SP.sea_limitation,SP.ETA,SP.EDD,SP.mtime,"
            . " SP.boat_id,B.boat_name,B.boat_code,SP.generalize,price_description")
             ->order('SP.ship_id,SP.mtime DESC')->group('SP.route_id,SP.ship_id')->select();
   
        foreach ($lists as $key => $list) {
            $lists[$key]['ship_short_name'] =rtrim($list['ship_id'].'_'.$list['ship_short_name'],'_');
            $lists[$key]['boat_name'] =rtrim(implode('_', array($list['ship_id'],$list['boat_id'],$list['boat_code'])),'_');
        }    
//        $this->_p($lists);exit;
       
	$file_name = date('Y-m-d_His').'.csv';  
        $path = dirname( ROOT_PATH . 'public' . DS . 'uploads/excel'); 
        $tileArray=["ID","船公司ID","船名","路线id","起运港口","目的港口","中间港口","船舶ID","船舶名字","船舶航次","是否推荐","价格说明"];
        $dataArray=$lists;
        $this->exportToExcel($file_name, $tileArray, $dataArray);
    }
    
    /**
     * @creator Jimmy
     * @data 2018/1/05
     * @desc 数据导出到excel(csv文件)
     * @param $filename 导出的csv文件名称 如date("Y年m月j日").'-test.csv'
     * @param array $tileArray 所有列名称
     * @param array $dataArray 所有列数据
     */
    public  function exportToExcel($filename, $tileArray=[], $dataArray=[]){
        Loader::import('PHPExcel.Classes.PHPExcel'); //手动引入PHPExcel.php
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
        ini_set('memory_limit','512M');
        ini_set('max_execution_time',0);
        ob_end_clean();
        ob_start();
        header("Content-Type: text/csv");
        header("Content-Disposition:filename=".$filename);
        $fp=fopen('php://output','w');
        fwrite($fp, chr(0xEF).chr(0xBB).chr(0xBF));//转码 防止乱码(比如微信昵称(乱七八糟的))
        fputcsv($fp,$tileArray);
        $index = 0;
        foreach ($dataArray as $item) {
            if($index==1000){
                $index=0;
                ob_flush();
                flush();
            }
            $index++;
            fputcsv($fp,$item);
        }
 
        ob_flush();
        flush();
        ob_end_clean();
    }
    
}
