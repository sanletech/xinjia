<?php
//后台模块配置文件
return [
  // 视图输出字符串内容替换
    'view_replace_str'       => [
        //重置'__STATIC__常量
        '__STATIC__'=>'/static/index',
    
    ],
];
