<?php
namespace app\index\model;
use think\Model;
class Test extends Model
{
   
}



?>