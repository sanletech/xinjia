<?php
/*
 *  航线运价批量导入导出
 */
namespace app\admin\controller;
use app\admin\common\Base;
use think\Request;
use think\Loader;
use think\Db;
use app\admin\model\ExportExcelDroplist;

class BulkData extends Base{
 
    //港到港批量导入页面
    public function price_route_excel(){
        return $this->view->fetch('excel/price_route_excel');
    }
    
    function import_excel(){
        $file = request()->file('excel');
        $info = $file->validate(['size'=>15678,'ext'=>'xlsx,xls'])
               ->move(ROOT_PATH . 'public' . DS . 'uploads'. DS .'excel');
        if(!$info){
            return '上传错误'.$file->getError();
        }

        $type =$info->getExtension(); 
        /** 实例化 */
        Loader::import('PHPExcel.Classes.PHPExcel'); //手动引入PHPExcel.php
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
        Loader::import('PHPExcel.Classes.PHPExcel.PHPExcel_Style_Alignment');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
        
        if ($type=='xlsx') { 
            $type='Excel2007'; 
        }elseif($type=='xls') { 
            $type = 'Excel5'; 
        } 
        ini_set('max_execution_time', '0');
//        Vendor('PHPExcel.PHPExcel');
        $objReader = \PHPExcel_IOFactory::createReader($type);//判断使用哪种格式
        $objReader ->setReadDataOnly(true); //只读取数据,会智能忽略所有空白行,这点很重要！！！
        $file_path= ROOT_PATH . 'public' . DS . 'uploads'. DS .'excel'. DS .$info->getSaveName();
        $objPHPExcel = $objReader->load($file_path); //加载Excel文件
        $sheetCount = $objPHPExcel->getSheetCount();//获取sheet工作表总个数
        $rowData = array();
        $RowNum = 0;
        /*读取表格数据*/
        for($i =0;$i <= $sheetCount-1;$i++){//循环sheet工作表的总个数
            $sheet = $objPHPExcel->getSheet($i);
            $highestRow = $sheet->getHighestRow();
            $RowNum += $highestRow-1;//计算所有sheet的总行数
            $highestColumn = $sheet->getHighestColumn();//总列数
            //从第$i个sheet的第1行开始获取数据
            for($row = 1;$row <= $highestRow;$row++){
                //把每个sheet作为一个新的数组元素 键名以sheet的索引命名 利于后期数组的提取
            $rowData[$i][] = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
          
            }
        }
        /*删除每行表头数据 整理成二维数组*/
        $temp=[];
        foreach($rowData as $k=>$v){
            $temp[$k] =array_column($v,0);
            array_shift($temp[$k]);
        }
        
        echo '<pre>';
        print_r($temp);//打印结果
        echo '</pre>';       
           echo '--------</br>';
       // $this->_v($RowNum);echo '--------</br>'; $this->_v($rowData);
//        return array("RowNum" => $RowNum,"Excel_Data" => $rowData);
    }

    //处理excel的数据到数据里
    public function seaprice_excel($rowData) {
        $tmp = [];
        $mtime = date('y-m-d H:i:s');//当前时间
        //前后三天
        $before_mtime= date('y-m-d H:i:s',  strtotime($mtime.'-1day'));
        $after_mtime= date('y-m-d H:i:s',  strtotime($mtime.'+1day'));      
        $response=[];
        $sheet_title =Db::name('shipcompany')->where('status',1)->order('id')->column('ship_short_name','id');
        foreach ($rowData as $sheets) {
            //循环每个sheet
            foreach ($sheets as $key=> $rows) {
                //新的航线运价需要1=>船公司id,3=>航线id, 
                //7=>20GP,40HQ海运费,船期,截单时间,海上时效,预计到港时间,13=>预计送货时间,
                //15=>船舶ID,18=>是否推荐,19=>价格说明
                $tmp['ship_id']=$rows['1'];
                $tmp['route_id']=$rows['3'];
                $tmp['boat_id']=$rows['15'];
                $tmp['price_20GP']=$rows['7'];
                $tmp['price_40HQ']=$rows['8'];
                $tmp['shipping_date']=$rows['9'];
                $tmp['cutoff_date']=$rows['10'];
                $tmp['sea_limitation']=$rows['11'];
                $tmp['generalize']=$rows['18'];
                $tmp['price_description']=$rows['18'];
                $tmp['mtime']=$mtime;
                $tmp['ETA']=$rows['12'];
                $tmp['EDD']=$rows['13'];
                //先查询是否有重复再数据库里
                $sqlLogs =[];
                $map= array_slice($tmp,0,3);
                $select_res = Db::name('seaprice')->where($map)
                    ->whereTime('mtime','between',[$before_mtime,$after_mtime])
                    ->limit(1)->value('id');
                if(!$res){
                    $insert_res=Db::name('seaprice')->inset($tmp);
                }  else {
                    $sqlLogs =['status'=>0,'message'=>'存在重复航线','ID'=>''];
                }
               
               
            }
            
            
        }
        
    }
    
    

    /**
     * @creator Jimmy
     * @data 2018/1/05
     * @desc 数据导出到excel(csv文件)
     * @param $filename 导出的csv文件名称 如date("Y年m月j日").'-test.csv'
     * @param array $tileArray 所有列名称
     * @param array $dataArray 所有列数据
     */
    function exportExcel($expTitle,$expCellName,$expTableData,$sheetName,$tableHeader='',$defaultWidth=15)
    {
        /**文件名称*/
        $xlsTitle = iconv('utf-8', 'gb2312', $expTitle);
        $fileName = $expTitle.date('_Ymd');
        $cellNum = count($expCellName);

        /** 实例化 */
        Loader::import('PHPExcel.Classes.PHPExcel'); //手动引入PHPExcel.php
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
        Loader::import('PHPExcel.Classes.PHPExcel.PHPExcel_Style_Alignment');//引入IOFactory.php 文件里面的PHPExcel_IOFactory这个类
        $objPHPExcel = new \PHPExcel();
        $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');

        /** 缺省情况下,PHPExcel会自动创建第一个SHEET，其索引SheetIndex=0 */
        /** 设置 当前处于活动状态的SHEET 为PHPExcel自动创建的第一个SHEET */
        foreach($expTableData as $key => $item) {
            if($key !== 0) {$objPHPExcel->createSheet();}
            $objPHPExcel->setactivesheetindex($key);
            /** 设置工作表名称 */ 
            $objPHPExcel->getActiveSheet($key)->setTitle($sheetName[$key]);

            for($i = 0; $i < $cellNum; $i++)
            {
                /** 垂直居中 */
                $objPHPExcel->setActiveSheetIndex($key)->getStyle($cellName[$i])->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                /** 水平居中 */
                $objPHPExcel->setActiveSheetIndex($key)->getStyle($cellName[$i])->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
                /** 设置默认宽度 */
                $objPHPExcel->setActiveSheetIndex($key)->getColumnDimension($cellName[$i])->setWidth($defaultWidth);
                $objPHPExcel->setActiveSheetIndex($key)->setCellValue($cellName[$i].'1', $tableHeader[$i]);
            }

            /** 写入多行数据 */
            for($i = 0; $i < count($item); $i++)
            {
                for($j = 0; $j < $cellNum; $j++)
                {
                  $objPHPExcel->getActiveSheet($key)->setCellValue($cellName[$j].($i+2), $item[$i][$expCellName[$j]]);
                }
            }
        }

        /** 设置第一个工作表为活动工作表 */
        $objPHPExcel->setactivesheetindex(0);
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        ob_end_clean();//清除缓冲区,避免乱码
        @header('pragma:public');
        @header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        @header("Content-Disposition:attachment;filename=$fileName.xlsx");//attachment新窗口打印inline本窗口打印
        @header('Cache-Control: max-age=0');
        $objWriter->save('php://output');
        unset($objPHPExcel);exit;

    }
    //海运价格导出excel
    public function seaprcie_outExcel () {
        $sea_price_lists =Db::name('seaprice')->alias('SP')
               ->join('hl_ship_route SR','SR.id=SP.route_id','left')
               ->join('hl_sea_bothend SB','SB.sealine_id =SR.bothend_id','left')
               ->join('hl_sea_middle SM','SR.middle_id=SM.sealine_id','left')
               ->join('hl_port P1','P1.port_code= SB.sl_start','left')
               ->join('hl_port P2','P2.port_code= SB.sl_end','left')
               ->join('hl_port P3','P3.port_code= SM.sl_middle','left')
               ->join('hl_shipcompany SC',"SC.id=SP.ship_id and SC.status='1'",'left')
               ->join('hl_boat B','B.id=SP.boat_id','left')
               ->field("SP.id,SP.ship_id,SC.ship_short_name,SP.route_id,P1.port_name s_port,P2.port_name e_port,"
               . " group_concat(distinct P3.port_name order by SM.sequence separator '-') m_port,"
             . " SP.price_20GP,SP.price_40HQ,SP.shipping_date,SP.cutoff_date,SP.sea_limitation,SP.ETA,SP.EDD,SP.mtime,"
               . " SP.boat_id,B.boat_name,B.boat_code,SP.generalize,price_description")
                ->order('SP.ship_id')->where('SP.status',1)->group('SP.route_id,SP.ship_id')->select();
        $sea_price_arr = []; //海运价格分组
        $sea_price_head =array('ID','船公司ID','船公司','航线ID','起运港','目的港',
            '中间港口','20GP海运费','40HQ海运费','船期','截单时间','海上时效',
            '预计到港时间','预计送货时间','创建时间','船舶ID','船名','航次',
            '是否推荐','价格说明');
        
        foreach ($sea_price_lists as  $sea_price_list) {
            $key = $sea_price_list['ship_id'];
            $sea_price_arr[$key][] = $sea_price_list;
           
        }
        //船公司id数组
        $ship_id_arr= array_filter(array_keys($sea_price_arr));
        //生成航运价格excel
        $expTitle ='海运价格明细'; 
        $expTableData = array_values($sea_price_arr);
        $expCellName = array_keys($expTableData['0']['0']);
        $tableHeader= $sea_price_head;
        $sheetName =Db::name('shipcompany')->where('id','in',$ship_id_arr)->order('id')->column('ship_short_name') ;
        $expTableData = array_values($sea_price_arr);
        $this->exportExcel($expTitle, $expCellName, $expTableData, $sheetName,$tableHeader)   ;  

    }
    //船舶导出excl
    public function boat_outExcel () {
        $boat_arr=[];   //船舶分组
        $boat_lists= Db::name('boat')->field('id,boat_name,boat_code,ship_id')->where('status',1)->select();
        foreach ($boat_lists as $boat_list) {
            $key =$boat_list['ship_id'];
            $boat_arr[$key][] =$boat_list;
        }
        //船舶对应的船公司id数组
        $boat_ship_id_arr= array_filter(array_keys($boat_arr));
        $boat_expCellName =array('id','boat_name','boat_code','ship_id');
        $boat_expTableData = array_values($boat_arr);//每行的键数组
        $boat_head =array('ID','船名','航次','船公司ID');//表头
        $boat_sheetName = Db::name('shipcompany')->where('id','in',$boat_ship_id_arr)->order('id')->column('ship_short_name') ;
//        $this->_p($boat_expTableData);$this->_p($boat_sheetName);exit;
        $this->exportExcel('船公司对应船舶明细', $boat_expCellName,$boat_expTableData,$boat_sheetName,$boat_head); 

    }
 }
