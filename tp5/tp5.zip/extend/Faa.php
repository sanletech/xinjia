<?php

namespace Hello;

class Foo 
{
}
